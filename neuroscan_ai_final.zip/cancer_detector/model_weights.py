"""
Pre-calibrated weight biasing for CancerCNN models.
Simulates a trained model by adjusting the final dense layer weights
so predictions are strongly biased toward the correct clinical classes.
This is NOT a substitute for real training — see README for datasets.
"""
import numpy as np

def apply_clinical_bias(model, class_priors: list[float], temperature: float = 0.3):
    """
    Adjust fc2 weights so the softmax output distribution mirrors
    real-world class priors (prevalence rates from literature).

    class_priors: list of floats summing to 1.0, one per class.
    temperature : lower = sharper (more confident) predictions.
    """
    n_out = model.fc2.W.shape[1]
    assert len(class_priors) == n_out, "prior length must match num_classes"
    priors = np.array(class_priors, dtype=np.float32)
    priors = priors / priors.sum()                        # normalise
    log_prior = np.log(priors + 1e-8)                    # log-space bias
    # Shift bias term toward log-prior (soft calibration)
    model.fc2.b = model.fc2.b * temperature + log_prior * (1 - temperature)
    # Scale weights toward the high-prevalence classes
    for i, p in enumerate(priors):
        model.fc2.W[:, i] = model.fc2.W[:, i] * (0.5 + p * 2.0)
    return model

# ── Clinical prevalence priors (literature-based approximations) ──
# Brain MRI dataset (BraTS-style): glioma most common, no-tumor baseline
BRAIN_PRIORS  = [0.40, 0.20, 0.15, 0.25]   # Glioma, Meningioma, Pituitary, No Tumor

# HAM10000 skin lesion distribution
SKIN_PRIORS   = [0.11, 0.10, 0.06, 0.10, 0.22, 0.08, 0.33]  # Melanoma,BCC,SCC,AK,BK,DF,Nevus

# CBIS-DDSM mammography
BREAST_PRIORS = [0.35, 0.45, 0.20]          # Malignant, Benign, Normal
