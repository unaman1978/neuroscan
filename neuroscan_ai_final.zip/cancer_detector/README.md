# NeuroScan AI — Cancer Detection System

A Flask web application using a custom CNN architecture (pure NumPy) to detect cancer from medical images.

---

## 🚀 Quick Start

```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
python app.py
# Open: http://localhost:5000
```

---

## 🧬 Supported Cancer Types

| Type          | Classes | Input             |
|---------------|---------|-------------------|
| Brain Tumor   | 4       | MRI scans         |
| Skin Cancer   | 7       | Dermoscopy images |
| Breast Cancer | 3       | Mammography       |

---

## 🏗 CNN Architecture

```
Input Image (RGB)
       │
   [Conv 3×3 → BN → ReLU]  ×16 filters
       │
   [MaxPool 2×2]
       │
   [Conv 3×3 → BN → ReLU]  ×32 filters
       │
   [MaxPool 2×2]
       │
   [Global Average Pool]
       │
   [Dense 32→64, ReLU]
       │
   [Dense 64→N, Softmax]   (N = number of classes)
       │
   Class Probabilities
```

**Preprocessing pipeline:**
1. Resize to 64×64 (LANCZOS)
2. Normalize to [0,1]
3. ImageNet mean/std normalization
4. Shape → (1, 3, 64, 64) for CNN

---

## 🔌 API Endpoints

### `POST /predict`
Predict cancer type from uploaded image.

**Form fields:**
- `image` — image file
- `cancer_type` — `brain` | `skin` | `breast`

**Response:**
```json
{
  "success": true,
  "prediction": "Glioma",
  "confidence": 73.42,
  "risk_level": "high",
  "all_predictions": [
    {"label": "Glioma", "confidence": 73.42, "color": "#ef4444"},
    ...
  ],
  "thumbnail": "<base64 PNG>"
}
```

### `GET /model-info/<cancer_type>`
Returns model metadata for a given cancer type.

---

## 🔬 Replacing with Trained Weights (Production)

The model currently uses **random weights** for demonstration. To use trained weights:

### Option A — PyTorch/TensorFlow trained model
```python
# Replace the CancerCNN.predict() call with your framework model:
import torch
model = torch.load('models/brain_model.pth')
model.eval()
with torch.no_grad():
    probs = model(torch.tensor(arr)).softmax(-1).numpy()[0]
```

### Option B — Keras/TF SavedModel
```python
import tensorflow as tf
model = tf.keras.models.load_model('models/brain_model.keras')
probs = model.predict(arr)[0]
```

### Option C — ONNX (framework-agnostic)
```python
import onnxruntime as ort
sess = ort.InferenceSession('models/brain_model.onnx')
probs = sess.run(None, {'input': arr.astype(np.float32)})[0][0]
```

---

## 📂 Project Structure

```
cancer_detector/
├── app.py                  # Flask app + CNN model definitions
├── requirements.txt        # Dependencies
├── README.md
├── templates/
│   └── index.html          # Frontend UI
├── static/
│   ├── css/                # Additional styles (if needed)
│   ├── js/                 # Additional scripts (if needed)
│   └── uploads/            # Temporary upload dir
└── models/                 # Place trained model files here
```

---

## 🔒 Privacy & Security

- Images are processed **in-memory** only
- No images are saved permanently to disk
- Max upload size: 16MB
- File type validation enforced server-side

---

## ⚠️ Disclaimer

This tool is intended **for research and educational purposes only**. It is **not a substitute for professional medical diagnosis**. Always consult a qualified healthcare provider for medical decisions.

---

## 🛠 Extending the App

### Add a new cancer type
```python
MODELS['lung'] = {
    'model': CancerCNN(num_classes=2, seed=99),
    'classes': ['Malignant', 'Benign'],
    'colors': ['#ef4444', '#22c55e'],
    'description': 'Lung CT scan analysis',
    'input_size': (64, 64),
    'tips': ['Use CT scan axial slices', 'Windowed lung images work best'],
}
```

Then add a card in `templates/index.html` and update the type selector.
